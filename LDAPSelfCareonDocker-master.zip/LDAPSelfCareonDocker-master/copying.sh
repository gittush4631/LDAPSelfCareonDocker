#/bin/bash
cp /tmp/LdapCon.properties /opt/ibm/wlp/usr/servers/defaultServer/apps/expanded/LDAPSelfCare.war/WEB-INF/classes/LdapCon.properties
echo "COPIED"
